# Mi Página Web

Este es el repositorio de mi página web.

## Contiene:
- **index.html**: Página principal lista para usar.
- Ideal para subir a **GitHub Pages**.

## Cómo publicarla en GitHub Pages
1. Sube estos archivos a tu repositorio.
2. Ve a **Settings › Pages**.
3. En "Branch", selecciona **main** y carpeta `/root`.
4. Guarda.
5. Tu página estará disponible en unos segundos.

¡Listo para usar! 🚀
